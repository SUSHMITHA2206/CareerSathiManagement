package com.example.career.controller;

import com.example.career.exception.ResourceNotFoundException;
import com.example.career.model.Student;
import com.example.career.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    // Get all students
    @GetMapping("/students")
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    // Create new student
    @PostMapping("/students")
    public Student createStudent(@RequestBody Student student) {
        return studentRepository.save(student);
    }

    // Get student by ID
    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
        return ResponseEntity.ok(student);
    }

    // Update student profile
    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(
            @PathVariable Long id,
            @RequestBody Student studentDetails) {
        
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));

        // Update only non-null fields
        if (studentDetails.getName() != null) {
            student.setName(studentDetails.getName());
        }
        if (studentDetails.getMajor() != null) {
            student.setMajor(studentDetails.getMajor());
        }
        if (studentDetails.getGpa() != null) {
            student.setGpa(studentDetails.getGpa());
        }
        if (studentDetails.getAnnualIncome() != null) {
            student.setAnnualIncome(studentDetails.getAnnualIncome());
        }
        if (studentDetails.getFamilySize() != null) {
            student.setFamilySize(studentDetails.getFamilySize());
        }

        Student updatedStudent = studentRepository.save(student);
        return ResponseEntity.ok(updatedStudent);
    }

    // Delete student
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteStudent(@PathVariable Long id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
        
        studentRepository.delete(student);
        
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

    // Get students by financial criteria (example additional endpoint)
    @GetMapping("/financial/{minIncome}/{maxIncome}")
    public List<Student> getStudentsByIncomeRange(
            @PathVariable Double minIncome,
            @PathVariable Double maxIncome) {
        return studentRepository.findByAnnualIncomeBetween(minIncome, maxIncome);
    }
}