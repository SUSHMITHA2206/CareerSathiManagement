//package com.example.career.serviceimpl;
//
//import java.time.LocalDateTime;
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//import com.example.career.DTO.FinancialAidRequestDTO;
//import com.example.career.exception.ResourceNotFoundException;
//import com.example.career.model.FinancialAidApplication;
//import com.example.career.model.Student;
//import com.example.career.repository.ApplicationRepository;
//import com.example.career.service.FinancialAidService;
//
//@Service
//public class FinancialAidServiceImpl implements FinancialAidService {
//
//    private final ApplicationRepository applicationRepository;
//
//    public FinancialAidServiceImpl(ApplicationRepository applicationRepository) {
//        this.applicationRepository = applicationRepository;
//    }
//
//    @Override
//    public FinancialAidApplication createApplication(Student student, FinancialAidRequestDTO request) {
//        FinancialAidApplication application = new FinancialAidApplication();
//        application.setStudent(student);
//        application.setAidType(request.getAidType());
//        application.setAmountRequested(request.getAmountRequested());
//        application.setReason(request.getReason());
//        application.setSupportingDocuments(request.getSupportingDocuments());
//        application.setApplicationDate(LocalDateTime.now());
//        application.setStatus("PENDING");
//        
//        return applicationRepository.save(application);
//    }
//
//    @Override
//    public List<FinancialAidApplication> getStudentApplications(Long studentId) {
//        return applicationRepository.findByStudentId(studentId);
//    }
//
//    @Override
//    public FinancialAidApplication getApplication(Long applicationId, Long studentId) {
//        return applicationRepository.findByIdAndStudentId(applicationId, studentId)
//                .orElseThrow(() -> new ResourceNotFoundException(
//                        "Application not found with id " + applicationId + " for student " + studentId));
//    }
//
//    @Override
//    public FinancialAidApplication updateApplication(Long applicationId, Long studentId, FinancialAidRequestDTO request) {
//        FinancialAidApplication existingApplication = getApplication(applicationId, studentId);
//        
//        existingApplication.setAidType(request.getAidType());
//        existingApplication.setAmountRequested(request.getAmountRequested());
//        existingApplication.setReason(request.getReason());
//        existingApplication.setSupportingDocuments(request.getSupportingDocuments());
//        
//        return applicationRepository.save(existingApplication);
//    }
//}