package com.example.career.DTO;

import java.time.LocalDateTime;
import jakarta.validation.constraints.NotNull;

public class TrainingDTO {

    public static class SessionResponse {
        private Long id;
        private String title;
        private String description;
        private String instructor;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private Integer availableSeats;
        private String location;
        
        // Getters and Setters
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        
        public String getInstructor() { return instructor; }
        public void setInstructor(String instructor) { this.instructor = instructor; }
        
        public LocalDateTime getStartTime() { return startTime; }
        public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
        
        public LocalDateTime getEndTime() { return endTime; }
        public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
        
        public Integer getAvailableSeats() { return availableSeats; }
        public void setAvailableSeats(Integer availableSeats) { this.availableSeats = availableSeats; }
        
        public String getLocation() { return location; }
        public void setLocation(String location) { this.location = location; }
    }

    public static class RegisterRequest {
        @NotNull 
        private Long sessionId;
        private Long studentId;
        
        public Long getSessionId() { return sessionId; }
        public void setSessionId(Long sessionId) { this.sessionId = sessionId; }
        public Long getStudentId() { return studentId; }
        public void setStudentId(Long studentId) { this.studentId = studentId; }
    }
    
    public static class SessionRequest {
        @NotNull private String title;
        private String description;
        @NotNull private String instructor;
        @NotNull private LocalDateTime startTime;
        @NotNull private LocalDateTime endTime;
        @NotNull private Integer totalSeats;
        private String location;
        
        // Getters and Setters
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        
        public String getInstructor() { return instructor; }
        public void setInstructor(String instructor) { this.instructor = instructor; }
        
        public LocalDateTime getStartTime() { return startTime; }
        public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
        
        public LocalDateTime getEndTime() { return endTime; }
        public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
        
        public Integer getTotalSeats() { return totalSeats; }
        public void setTotalSeats(Integer totalSeats) { this.totalSeats = totalSeats; }
        
        public String getLocation() { return location; }
        public void setLocation(String location) { this.location = location; }
    }
}