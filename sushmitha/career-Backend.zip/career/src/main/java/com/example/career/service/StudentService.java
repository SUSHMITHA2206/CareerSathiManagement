package com.example.career.service;

import com.example.career.model.Student;
import java.util.List;

public interface StudentService {
    List<Student> getAllStudents();
    Student getStudentById(Long id);
    Student createStudent(Student student);
    Student updateStudent(Long id, Student studentDetails);
    void deleteStudent(Long id);
    List<Student> getStudentsByIncomeRange(Double minIncome, Double maxIncome);
    Student updateStudentFinancialInfo(Long id, Double annualIncome, Integer familySize);
}