//package com.example.career.controller;
//
//import com.example.career.model.Student;
//import com.example.career.service.DashboardService;
//
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.core.annotation.AuthenticationPrincipal;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/dashboard")
//public class DashboardController {
//
//    private final DashboardService dashboardService;
//
//    public DashboardController(DashboardService dashboardService) {
//        this.dashboardService = dashboardService;
//    }
//
//    @GetMapping
//    public ResponseEntity<?> getDashboard(@AuthenticationPrincipal Student student) {
//        return ResponseEntity.ok(dashboardService.getStudentDashboard(student.getId()));
//    }
//}