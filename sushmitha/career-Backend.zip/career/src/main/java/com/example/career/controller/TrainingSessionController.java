package com.example.career.controller;

import com.example.career.DTO.TrainingDTO;
import com.example.career.model.Applicant;
import com.example.career.model.Student;
import com.example.career.model.TrainingSession;
import com.example.career.repository.ApplicationRepository;
import com.example.career.repository.TrainingSessionRepository;
import com.example.career.service.TrainingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1")
public class TrainingSessionController {

	@Autowired
	private TrainingSessionRepository sessionRepository;
	
	// get all employees
	@GetMapping("/training")
	public List<TrainingSession> getAllEmployees(){
		return sessionRepository.findAll();
	}		
//    @GetMapping()
//    public ResponseEntity<List<TrainingDTO.SessionResponse>> getAvailableSessions() {
//        return ResponseEntity.ok(trainingService.getAvailableSessions());
//    }

//    @PostMapping("/register")
//    public ResponseEntity<?> registerSession(
//            @AuthenticationPrincipal Student student,
//            @RequestBody TrainingDTO.RegisterRequest request) {
//        request.setStudentId(student.getId());
//        trainingService.registerStudent(request);
//        return ResponseEntity.ok("Registration successful");
//    }

//    @PostMapping
//    public ResponseEntity<TrainingDTO.SessionResponse> createSession(
//            @RequestBody TrainingDTO.SessionRequest request) {
//        return ResponseEntity.ok(trainingService.createTrainingSession(request));
//    }
}