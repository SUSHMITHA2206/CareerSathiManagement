//package com.example.career.DTO;
//
//import java.util.List;
//
//public class DashboardDTO {
//    private String welcomeMessage;
//    private List<ApplicationDTO.StatusResponse> applications;
//    private Integer pendingApplications;
//    // Getters & Setters
//	public String getWelcomeMessage() {
//		return welcomeMessage;
//	}
//	public void setWelcomeMessage(String welcomeMessage) {
//		this.welcomeMessage = welcomeMessage;
//	}
//	public List<ApplicationDTO.StatusResponse> getApplications() {
//		return applications;
//	}
//	public void setApplications(List<ApplicationDTO.StatusResponse> applications) {
//		this.applications = applications;
//	}
//	public Integer getPendingApplications() {
//		return pendingApplications;
//	}
//	public void setPendingApplications(Integer pendingApplications) {
//		this.pendingApplications = pendingApplications;
//	}
//}