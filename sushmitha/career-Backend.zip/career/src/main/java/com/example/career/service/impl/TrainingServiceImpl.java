package com.example.career.service.impl;

import com.example.career.DTO.TrainingDTO;
import com.example.career.exception.ResourceNotFoundException;
import com.example.career.model.TrainingSession;
import com.example.career.model.Student;
import com.example.career.repository.TrainingSessionRepository;
import com.example.career.repository.StudentRepository;
import com.example.career.service.TrainingService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class TrainingServiceImpl implements TrainingService {

    private final TrainingSessionRepository trainingRepo;
    private final StudentRepository studentRepo;

    public TrainingServiceImpl(TrainingSessionRepository trainingRepo, 
                             StudentRepository studentRepo) {
        this.trainingRepo = trainingRepo;
        this.studentRepo = studentRepo;
    }

    @Override
    public List<TrainingDTO.SessionResponse> getAvailableSessions() {
        return trainingRepo.findByAvailableSeatsGreaterThan(0)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public void registerStudent(TrainingDTO.RegisterRequest request) {
        TrainingSession session = trainingRepo.findById(request.getSessionId())
                .orElseThrow(() -> new ResourceNotFoundException("Session not found"));
        
        Student student = studentRepo.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));
        
        if (session.getAvailableSeats() <= 0) {
            throw new IllegalStateException("No seats available");
        }
        
        session.getRegisteredStudents().add(student);
        session.setAvailableSeats(session.getAvailableSeats() - 1);
        trainingRepo.save(session);
    }

    @Override
    public List<TrainingDTO.SessionResponse> getRegisteredSessions(Long studentId) {
        return trainingRepo.findByRegisteredStudentsId(studentId)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    public List<TrainingDTO.SessionResponse> getUpcomingSessions() {
        LocalDateTime now = LocalDateTime.now();
        return trainingRepo.findByStartTimeAfterOrderByStartTimeAsc(now)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    @Override
    public TrainingDTO.SessionResponse createTrainingSession(TrainingDTO.SessionRequest request) {
        TrainingSession session = new TrainingSession();
        session.setTitle(request.getTitle());
        session.setDescription(request.getDescription());
        session.setInstructor(request.getInstructor());
        session.setStartTime(request.getStartTime());
        session.setEndTime(request.getEndTime());
        session.setTotalSeats(request.getTotalSeats());
        session.setLocation(request.getLocation());
        
        TrainingSession savedSession = trainingRepo.save(session);
        return convertToResponse(savedSession);
    }

    private TrainingDTO.SessionResponse convertToResponse(TrainingSession session) {
        TrainingDTO.SessionResponse response = new TrainingDTO.SessionResponse();
        response.setId(session.getId());
        response.setTitle(session.getTitle());
        response.setDescription(session.getDescription());
        response.setInstructor(session.getInstructor());
        response.setStartTime(session.getStartTime());
        response.setEndTime(session.getEndTime());
        response.setAvailableSeats(session.getAvailableSeats());
        response.setLocation(session.getLocation());
        return response;
    }
}