package com.example.career.repository;

import com.example.career.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface StudentRepository extends JpaRepository<Student, Long> {
    
    // Custom query to find students by income range
    @Query("SELECT s FROM Student s WHERE s.annualIncome BETWEEN :minIncome AND :maxIncome")
    List<Student> findByAnnualIncomeBetween(
            @Param("minIncome") Double minIncome,
            @Param("maxIncome") Double maxIncome);
    
    // Add other custom queries as needed
}