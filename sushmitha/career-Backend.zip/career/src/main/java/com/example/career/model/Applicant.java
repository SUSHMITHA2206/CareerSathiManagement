package com.example.career.model;

import jakarta.persistence.*;


@Entity
@Table(name = "applications")
public class Applicant {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "name")
	private String name;

	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "annual_Income")
	private int annualIncome;
		
	@Column(name = "Documents")
	private String supportingDocuments;
	
	@Column(name = "financial_Need")
	private String financialNeed;
	
//	@Column(name="status")
//	private String status;
	
	  
	@Enumerated(EnumType.STRING)
    @Column(
        name = "status",
        nullable = false,
        columnDefinition = "VARCHAR(20) NOT NULL DEFAULT 'PENDING_REVIEW'"
    )
    private ApplicationStatus status = ApplicationStatus.PENDING_REVIEW;

    public enum ApplicationStatus {
        PENDING_REVIEW, 
        UNDER_EVALUATION, 
        APPROVED, 
        REJECTED
    }

	public Applicant() {
		
	}
	
	public Applicant(long id, String name, String emailId, int annualIncome, String supportingDocuments,
			String financialNeed) {
		super();
		this.id = id;
		this.name = name;
		this.emailId = emailId;
		this.annualIncome = annualIncome;
		this.supportingDocuments = supportingDocuments;
		this.financialNeed = financialNeed;
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(int annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getSupportingDocuments() {
		return supportingDocuments;
	}

	public void setSupportingDocuments(String supportingDocuments) {
		this.supportingDocuments = supportingDocuments;
	}

	public String getFinancialNeed() {
		return financialNeed;
	}

	public void setFinancialNeed(String financialNeed) {
		this.financialNeed = financialNeed;
	}
	
	// Add these to your entity class
	public ApplicationStatus getStatus() {
	    return status;
	}

	public void setStatus(ApplicationStatus status) {
	    this.status = status;
	}
	
	
}
































































//package com.example.career.model;
//
//import jakarta.persistence.*;
//import java.time.LocalDateTime;
//
//@Entity
//public class FinancialAidApplication {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//    
//    @ManyToOne
//    @JoinColumn(name = "student_id", nullable = false)
//    private Student student;
//    
//    private String aidType;
//    private Double amountRequested;
//    private String reason;
//    private String supportingDocuments;
//    private LocalDateTime applicationDate;
//    private String status;
//
//    // Constructors
//    public FinancialAidApplication() {}
//
//    // Getters
//    public Long getId() { return id; }
//    public Student getStudent() { return student; }
//    public String getAidType() { return aidType; }
//    public Double getAmountRequested() { return amountRequested; }
//    public String getReason() { return reason; }
//    public String getSupportingDocuments() { return supportingDocuments; }
//    public LocalDateTime getApplicationDate() { return applicationDate; }
//    public String getStatus() { return status; }
//
//    // Setters
//    public void setId(Long id) { this.id = id; }
//    public void setStudent(Student student) { this.student = student; }
//    public void setAidType(String aidType) { this.aidType = aidType; }
//    public void setAmountRequested(Double amountRequested) { this.amountRequested = amountRequested; }
//    public void setReason(String reason) { this.reason = reason; }
//    public void setSupportingDocuments(String supportingDocuments) { 
//        this.supportingDocuments = supportingDocuments; 
//    }
//    public void setApplicationDate(LocalDateTime applicationDate) { 
//        this.applicationDate = applicationDate; 
//    }
//    public void setStatus(String status) { this.status = status; }
//}
//
//
//
//
//
