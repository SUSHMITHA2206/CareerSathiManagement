//package com.example.career.service;
//
//import com.example.career.DTO.FinancialAidRequestDTO;
//import com.example.career.model.FinancialAidApplication;
//import com.example.career.model.Student;
//import java.util.List;
//
//public interface FinancialAidService {
//    FinancialAidApplication createApplication(Student student, FinancialAidRequestDTO request);
//    List<FinancialAidApplication> getStudentApplications(Long studentId);
//    FinancialAidApplication getApplication(Long applicationId, Long studentId);
//    FinancialAidApplication updateApplication(Long applicationId, Long studentId, FinancialAidRequestDTO request);
//    
//   
//}
//
