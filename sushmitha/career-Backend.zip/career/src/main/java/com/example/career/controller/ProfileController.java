//package com.example.career.controller;
//
//import com.example.career.DTO.ProfileDTO;
//import com.example.career.model.Student;
//import com.example.career.service.ProfileService;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.core.annotation.AuthenticationPrincipal;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/profile")
//public class ProfileController {
//
//    private final ProfileService profileService;
//
//    public ProfileController(ProfileService profileService) {
//        this.profileService = profileService;
//    }
//
//    @PutMapping
//    public ResponseEntity<Student> updateProfile(
//            @AuthenticationPrincipal Student student,
//            @RequestBody ProfileDTO request) {
//        return ResponseEntity.ok(
//            profileService.updateStudentProfile(student.getId(), request)
//        );
//    }
//}