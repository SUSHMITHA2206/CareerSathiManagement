//package com.example.career.service;
//
//import com.example.career.DTO.ProfileDTO;
//import com.example.career.exception.ResourceNotFoundException;
//import com.example.career.model.Student;
//import com.example.career.repository.StudentRepository;
//import org.springframework.stereotype.Service;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.core.annotation.AuthenticationPrincipal;
//import org.springframework.web.bind.annotation.*;
//
//// ========== Interface ==========
//public interface ProfileService {
//    Student getStudentProfile(Long studentId);
//    Student updateStudentProfile(Long studentId, ProfileDTO request);
//}
//
//// ========== Implementation ==========
//@Service
//class ProfileServiceImpl implements ProfileService {
//
//    private final StudentRepository studentRepository;
//
//    public ProfileServiceImpl(StudentRepository studentRepository) {
//        this.studentRepository = studentRepository;
//    }
//
//    @Override
//    public Student getStudentProfile(Long studentId) {
//        return studentRepository.findById(studentId)
//                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + studentId));
//    }
//
//    @Override
//    public Student updateStudentProfile(Long studentId, ProfileDTO request) {
//        Student student = getStudentProfile(studentId);
//        
//        // Update profile fields
//        if (request.getName() != null) student.setName(request.getName());
//        if (request.getMajor() != null) student.setMajor(request.getMajor());
//        if (request.getGpa() != null) student.setGpa(request.getGpa());
//        if (request.getAnnualIncome() != null) student.setAnnualIncome(request.getAnnualIncome());
//        if (request.getFamilySize() != null) student.setFamilySize(request.getFamilySize());
//        
//        return studentRepository.save(student);
//    }
//}
//
//
