package com.example.career.service;

import com.example.career.DTO.TrainingDTO;
import java.util.List;

public interface TrainingService {
    List<TrainingDTO.SessionResponse> getAvailableSessions();
    void registerStudent(TrainingDTO.RegisterRequest request);
    List<TrainingDTO.SessionResponse> getRegisteredSessions(Long studentId);
    List<TrainingDTO.SessionResponse> getUpcomingSessions();
    TrainingDTO.SessionResponse createTrainingSession(TrainingDTO.SessionRequest request);
}