package com.example.career.DTO;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class ApplicationDTO {

    // Submit Application (from UI form)
    public static class SubmitRequest {
        @NotNull @Positive 
        private BigDecimal annualIncome;
        @NotBlank @Size(max = 500) 
        private String financialDescription;
        // Getters & Setters
    }

    // Application Status (for tracking)
    public static class StatusResponse {
        private String applicationId;
        private String status; // "PENDING"/"APPROVED"/"REJECTED"
        private LocalDateTime submittedDate;
        // Getters & Setters
    }
}