package com.example.career.serviceimpl;

import com.example.career.exception.ResourceNotFoundException;
import com.example.career.model.Student;
import com.example.career.repository.StudentRepository;
import com.example.career.service.StudentService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;

    public StudentServiceImpl(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Override
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @Override
    public Student getStudentById(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
    }

    @Override
    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }

    @Override
    public Student updateStudent(Long id, Student studentDetails) {
        Student student = getStudentById(id);

        if (studentDetails.getName() != null) {
            student.setName(studentDetails.getName());
        }
        if (studentDetails.getMajor() != null) {
            student.setMajor(studentDetails.getMajor());
        }
        if (studentDetails.getGpa() != null) {
            student.setGpa(studentDetails.getGpa());
        }
        if (studentDetails.getAnnualIncome() != null) {
            student.setAnnualIncome(studentDetails.getAnnualIncome());
        }
        if (studentDetails.getFamilySize() != null) {
            student.setFamilySize(studentDetails.getFamilySize());
        }

        return studentRepository.save(student);
    }

    @Override
    public void deleteStudent(Long id) {
        Student student = getStudentById(id);
        studentRepository.delete(student);
    }

    @Override
    public List<Student> getStudentsByIncomeRange(Double minIncome, Double maxIncome) {
        return studentRepository.findByAnnualIncomeBetween(minIncome, maxIncome);
    }

    @Override
    public Student updateStudentFinancialInfo(Long id, Double annualIncome, Integer familySize) {
        Student student = getStudentById(id);
        
        if (annualIncome != null) {
            student.setAnnualIncome(annualIncome);
        }
        if (familySize != null) {
            student.setFamilySize(familySize);
        }
        
        return studentRepository.save(student);
    }
}