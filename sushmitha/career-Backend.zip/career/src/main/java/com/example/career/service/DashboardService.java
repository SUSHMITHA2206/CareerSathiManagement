//package com.example.career.service;
//
//import com.example.career.repository.ApplicationRepository;
//import com.example.career.service.TrainingService;
//import org.springframework.stereotype.Service;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Service
//public class DashboardService {
//
//    private final ApplicationRepository applicationRepository;
//    private final TrainingService trainingService;
//
//    public DashboardService(ApplicationRepository applicationRepository, 
//                          TrainingService trainingService) {
//        this.applicationRepository = applicationRepository;
//        this.trainingService = trainingService;
//    }
//
//    public Map<String, Object> getStudentDashboard(Long studentId) {
//        Map<String, Object> dashboardData = new HashMap<>();
//
//        // Application stats
//        dashboardData.put("applications", applicationRepository.findByStudentId(studentId));
//        dashboardData.put("pendingCount", applicationRepository.countByStudentIdAndStatus(
//            studentId, "PENDING"));
//        dashboardData.put("approvedCount", applicationRepository.countByStudentIdAndStatus(
//            studentId, "APPROVED"));
//
//        // Training sessions
//        dashboardData.put("upcomingSessions", trainingService.getUpcomingSessions());
//        dashboardData.put("registeredSessions", trainingService.getRegisteredSessions(studentId));
//
//        return dashboardData;
//    }
//}