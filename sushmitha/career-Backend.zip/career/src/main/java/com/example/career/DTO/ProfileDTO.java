//package com.example.career.DTO;
//
//public class ProfileDTO {
//    private String name;
//    private String major;
//    private Double gpa;
//    private Double annualIncome;
//    private Integer familySize;
//
//    // Getters and Setters
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getMajor() {
//        return major;
//    }
//
//    public void setMajor(String major) {
//        this.major = major;
//    }
//
//    public Double getGpa() {
//        return gpa;
//    }
//
//    public void setGpa(Double gpa) {
//        this.gpa = gpa;
//    }
//
//    public Double getAnnualIncome() {
//        return annualIncome;
//    }
//
//    public void setAnnualIncome(Double annualIncome) {
//        this.annualIncome = annualIncome;
//    }
//
//    public Integer getFamilySize() {
//        return familySize;
//    }
//
//    public void setFamilySize(Integer familySize) {
//        this.familySize = familySize;
//    }
//}