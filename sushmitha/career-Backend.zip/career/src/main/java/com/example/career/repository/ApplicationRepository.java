package com.example.career.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.career.model.Applicant;

import com.example.career.model.Applicant;



    
@Repository
public interface ApplicationRepository extends JpaRepository<Applicant, Long> {
	
	Optional<Applicant> findByIdAndEmailId(Long id, String emailId);
	

}
