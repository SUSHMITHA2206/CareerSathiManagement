package com.example.career.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.career.exception.*;
import com.example.career.model.Applicant;
import com.example.career.model.Applicant.ApplicationStatus;
import com.example.career.model.Applicant;
import com.example.career.repository.ApplicationRepository;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1")
public class FinancialAidController {

	@Autowired
	private ApplicationRepository applicantRepository;
	
	// get all employees
	@GetMapping("/applications")
	public List<Applicant> getAllEmployees(){
		return applicantRepository.findAll();
	}		
	
	// create employee rest api
	@PostMapping("/applications")
	public Applicant createApplicant(@RequestBody Applicant applicant) {
		return applicantRepository.save(applicant);
	}
	
//	@PutMapping("/applications/{id}")
//	public ResponseEntity<Applicant> updateStatus(
//	    @PathVariable Long id,
//	    @RequestParam ApplicationStatus newStatus // Use enum type directly
//	) {
//	    Applicant applicant = applicantRepository.findById(id)
//	        .orElseThrow(() -> new ResourceNotFoundException("Application not found"));
//	    
//	    applicant.setStatus(newStatus);
//	    Applicant updated = applicantRepository.save(applicant);
//	    return ResponseEntity.ok(updated);
//	}
//	
	
	
////	 get employee by id rest api
//	@GetMapping("/applications/{id}")
//	public ResponseEntity<Applicant> getApplicantById(@PathVariable Long id) {
//		Applicant applicant = applicantRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
//		return ResponseEntity.ok(applicant);
//	}
	@GetMapping("/applications/{id}/status")
	public ResponseEntity<Map<String, String>> checkApplicationStatus(
	    @PathVariable Long id,
	    @RequestParam String email
	) {
	    Applicant application = applicantRepository.findByIdAndEmailId(id, email)
	        .orElseThrow(() -> new ResourceNotFoundException(
	            "Application not found with ID: " + id + " and email: " + email));
	    
	    Map<String, String> response = new HashMap<>();
	    response.put("status", application.getStatus().name());
	    return ResponseEntity.ok(response);
	}
	
	
	
	
	
	// update employee rest api
	
//	@PutMapping("/employees/{id}")
//	public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails){
//		Employee employee = employeeRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
//		
//		employee.setFirstName(employeeDetails.getFirstName());
//		employee.setLastName(employeeDetails.getLastName());
//		employee.setEmailId(employeeDetails.getEmailId());
//		
//		Employee updatedEmployee = employeeRepository.save(employee);
//		return ResponseEntity.ok(updatedEmployee);
//	}
	
//	
//	@GetMapping("/viewapplications/")
//	public ResponseEntity<Map<String, String>> viewApplication() {
//	    Applicant application = applicantRepository.findAll()
//	    }
//	
	// delete employee rest api
//	@DeleteMapping("/employees/{id}")
//	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id){
//		Employee employee = employeeRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
//		
//		employeeRepository.delete(employee);
//		Map<String, Boolean> response = new HashMap<>();
//		response.put("deleted", Boolean.TRUE);
//		return ResponseEntity.ok(response);
//	}
//	
	
}
