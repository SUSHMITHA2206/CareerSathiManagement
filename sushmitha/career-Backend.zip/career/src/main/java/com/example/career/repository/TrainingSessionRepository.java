package com.example.career.repository;

import com.example.career.model.TrainingSession;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface TrainingSessionRepository extends JpaRepository<TrainingSession, Long> {
    List<TrainingSession> findByAvailableSeatsGreaterThan(int seats);
    List<TrainingSession> findByRegisteredStudentsId(Long studentId);
    List<TrainingSession> findByStartTimeAfterOrderByStartTimeAsc(LocalDateTime startTime);
}