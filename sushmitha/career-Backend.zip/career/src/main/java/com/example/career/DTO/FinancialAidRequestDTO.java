package com.example.career.DTO;

public class FinancialAidRequestDTO {
    private String aidType;
    private Double amountRequested;
    private String reason;
    private String supportingDocuments;

    public FinancialAidRequestDTO() {}

    public FinancialAidRequestDTO(String aidType, Double amountRequested, String reason, String supportingDocuments) {
        this.aidType = aidType;
        this.amountRequested = amountRequested;
        this.reason = reason;
        this.supportingDocuments = supportingDocuments;
    }

    // Getters
    public String getAidType() { return aidType; }
    public Double getAmountRequested() { return amountRequested; }
    public String getReason() { return reason; }
    public String getSupportingDocuments() { return supportingDocuments; }

    // Setters
    public void setAidType(String aidType) { this.aidType = aidType; }
    public void setAmountRequested(Double amountRequested) { this.amountRequested = amountRequested; }
    public void setReason(String reason) { this.reason = reason; }
    public void setSupportingDocuments(String supportingDocuments) { 
        this.supportingDocuments = supportingDocuments; 
    }
}